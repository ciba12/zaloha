// Copyright 2006-2015 Coppelia Robotics GmbH. All rights reserved.
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
//
// -------------------------------------------------------------------
// THIS FILE IS disTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
//
// You are free to use/modify/distribute this file for whatever purpose!
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.2 Rev1 on September 5th 2015

// Make sure to have the server side running in V-REP!
// Start the server from a child script with following command:
// simExtRemoteApiStart(portNumber) -- starts a remote API server service on the specified port

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
//
#define NON_MATLAB_PARSING
#define MAX_EXT_API_CONNECTIONS 255
//
#ifndef VREP
#define VREP

#include "v_repConst.h"
#include "extApiPlatform.h"
#endif

#include "extApi.h"
#include "extApi.c"
#include "extApiPlatform.c"
#include "pom_fce.h"

#define TIME_STEP 0.05 //[sec]
#define COV_MAT 1 // meni tvar krivky pro vypocet Mi, cim vetsi, tim rychlejsi zmeny, Mi=1-exp((x^2+y^2) * COVMAT)
#define TAU 3 //time interval for derivation, higher TAU, more robust
#define ALFA 0.036 //higher ALFA, higher sensitivity to target dynamic's variations
#define NEIGH_DISTANCE 3 //range proximity senzoru
#define CIRCLE_DIST 1.8 //polomer kruhu ve kterzm se musi drzet
#define EPSILON 0.2
#define SWARM_QUANTITY 3  //velikost swarmu


#define ERR_POS 0.0
#define ERR_VISION 0.0
#define ERR_DIST 0.0
#define real_rand() ((double)rand() / (RAND_MAX +1.0) -0.5)

#define CONSOLE_LINES 5


//funguje do 0.7, vic uz nejde protoze se kamery naklani
//#define KP 23
//#define KI 0.56
//#define KD 130
//#define GAIN 0.05

//funguje do 0.5 rychlosti
#define KP 20
#define KI 0.56
#define KD 0
#define GAIN 0.05

int main(int argc, char *argv[]) {
	int portNb = 0;
	int target_koule;
	int camera_handle;
	int circle;
	int proximity[2];
	int ID_QUADCOPTER;

	int truek = 1;

	float *p_prusecik_vysledny = (float *) malloc(2 * sizeof(float));
	float eps[2] = { 0.0, 0.0 };

	//prevzeti handlu pres argument
	if (argc >= 8) {
		portNb = atoi(argv[1]);
		target_koule = atoi(argv[2]);
		camera_handle = atoi(argv[3]);
		circle = atoi(argv[4]);
		proximity[0] = atoi(argv[5]);
		proximity[1] = atoi(argv[6]);
		ID_QUADCOPTER = atoi(argv[7]);
	} else {
		return 0;
	}

	simxUChar image[100 * 100];
	for (int k = 0; k < 100 * 100; k++) {
		image[k] = 0;
	}

	//inicializace
	float position_mine[3] = { 0.0f, 0.0f, 0.0f };
	float position_neigh[3] = { 0.0f, 0.0f, 0.0f }; // pozice souseda
	float velocity_a[3] = { 0.0f, 0.0f, 0.0f }; //alfa velocity from target
	float sum_neigh[2] = { 0.0f, 0.0f };

	float euler_angles[3] = { 0.0f, 0.0f, 0.0f };
	int clientID = simxStart((simxChar *) "127.0.0.1", portNb, truek, truek, 2000, 5);
	//    simxSynchronous(clientID,true);

	//inicializace konzole
	char title[20];
	sprintf(title, "ID: %d", ID_QUADCOPTER);
	int *console_handle = (int *) malloc(sizeof(int));
	int size[2] = { 400, 2 };
	int position_console[2] = { 250, 1000 - 100 * ID_QUADCOPTER };
	simxAuxiliaryConsoleOpen(clientID, title, CONSOLE_LINES, 1, position_console, size, NULL, NULL, console_handle, simx_opmode_oneshot_wait);
	char text[200]; // pripraveny pro zapis do konzole
	char text_pom[100];

	float target_pos[2];
	float target_pos_int[2] = { 0.0, 0.0 };
	float target_pos_der[2] = { 0.0, 0.0 };
	float target_pos_old[2] = { 0.0, 0.0 };

	simxUChar detection_state; //jeje

	//init. sledovani targetu
	float Mi = 0;
	float Ax = 0, Ay = 0, dAx = 0, dAy = 0;
	float Ax_array[TAU];
	float Ay_array[TAU];

	for (int i = 0; i < TAU; i++) {
		Ax_array[i] = 0;
		Ay_array[i] = 0;
	}

	simxFloat **pp_auxVal = (simxFloat **) malloc(sizeof(simxFloat *) * 6);
	for (int i = 0; i < 6; ++i)
		pp_auxVal[i] = (simxFloat *) malloc(sizeof(simxFloat) * 15);

	simxInt **pp_auxValc = (simxInt **) malloc(sizeof(simxInt *) * 6);
	for (int i = 0; i < 6; ++i)
		pp_auxValc[i] = (simxInt *) malloc(sizeof(simxInt) * 15);


	int my_validity_prus = 0;
	int vision_data_validity = 0;

	char **receive_names = (char **) malloc(sizeof(char *) * SWARM_QUANTITY);
	for (int i = 0; i < SWARM_QUANTITY; i++) {
		receive_names[i] = (char *) malloc(sizeof(char) * 10);
		sprintf(receive_names[i], "%d", i + 1);
	}
	simxUChar **receive_str = (simxUChar **) malloc(sizeof(simxUChar *));
	receive_str[0] = (simxUChar *) malloc(sizeof(simxUChar) * 100);

	//beru handle odsud
	//simxGetObjectHandle(clientID, "Vision_sensor#0", &camera, simx_opmode_oneshot_wait);

	// pozadavky na server aby zacal streamovat
	simxGetObjectPosition(clientID, target_koule, -1, position_mine, simx_opmode_streaming);
	simxReadVisionSensor(clientID, camera_handle, &detection_state, pp_auxVal, pp_auxValc, simx_opmode_streaming);
	simxGetObjectOrientation(clientID, camera_handle, -1, euler_angles, simx_opmode_streaming);
	simxReadProximitySensor(clientID, proximity[0], NULL, position_neigh, NULL, NULL, simx_opmode_streaming);
	simxReadProximitySensor(clientID, proximity[1], NULL, position_neigh, NULL, NULL, simx_opmode_streaming);

	for (int i = 0; i < SWARM_QUANTITY; i++) {
		simxGetStringSignal(clientID, receive_names[i], receive_str, NULL, simx_opmode_streaming);
	}

	simxChar send_str[100];
	simxChar send_name[10];
	sprintf(send_name, "%d", ID_QUADCOPTER);

	int neigh_valid_count = 0;

	float PID_out[2];

	float rel_neigh_pos[2][2] = { { 0.0, 0.0 }, { 0.0, 0.0 } };
	int prusecik_error = 1;

	float err = 0, errpom[2] = { 0.0, 0.0 };
	float Sx[2] = { 0.0, 0.0 };
	float Sy[2] = { 0.0, 0.0 };
	float Sdist[2] = { 0.0, 0.0 };

	float delta;
	float alfax, alfay;

	int first_smooth = 1;

	if (clientID != -1) {
		while (simxGetConnectionId(clientID) != -1)    // dokud jsem pripojen k serveru....
		{

			//detekce targetu
			get_target_coordinates(clientID, camera_handle, ID_QUADCOPTER, target_pos, &vision_data_validity);

			if (vision_data_validity != 0) {
//				printf("target: %.2f %.2f \n", target_pos[0], target_pos[1]);
			} else {
//				printf("VISION DATA NOT VALID\n");
			}
//			vypocteni thrustu
			target_intercept_pid(target_pos, velocity_a, KP * GAIN, KI * GAIN, KD * GAIN);


//            detekce polohy sousedu
			/*------------------------------------------------------------------------------------------------------------------*/
			detect_neighbours(clientID,proximity,ID_QUADCOPTER, rel_neigh_pos, eps,CIRCLE_DIST);

			//prijem rychlosti sousedu
			/*------------------------------------------------------------------------------------------------------------------*/
			get_neightbour_velocities(clientID,ID_QUADCOPTER,rel_neigh_pos,SWARM_QUANTITY,&neigh_valid_count,receive_names,receive_str);


			//pocitani pruseciku
			/*------------------------------------------------------------------------------------------------------------------*/
			prusecik_error = nearest_intersection(rel_neigh_pos, CIRCLE_DIST,p_prusecik_vysledny);
//			printf("vysledny prus: %.2f, %.2f\n",p_prusecik_vysledny[0],p_prusecik_vysledny[1]);

			//update polohy koule
			/*------------------------------------------------------------------------------------------------------------------*/
			//odeslu svou vypocitanou rychlost ostatnim

			if (eps[0] > EPSILON || eps[1] > EPSILON || prusecik_error) {
				//zprumeruju s ostatnima
				position_mine[0] = TIME_STEP * p_prusecik_vysledny[0] / 3;
				position_mine[1] = TIME_STEP * p_prusecik_vysledny[1] / 3;
				my_validity_prus = 0;
//				                                printf("prumer s ostatnima : %f,,,%f\n",position_mine[0],position_mine[1]);
			} else {
				//jdu do pruseciku
				position_mine[0] = (TIME_STEP * velocity_a[0] + sum_neigh[0]) / (1 + neigh_valid_count);
				position_mine[1] = (TIME_STEP * velocity_a[1] + sum_neigh[1]) / (1 + neigh_valid_count);
				my_validity_prus = 1;
//				                                printf("prusecik vysledny: %f,,,%f\n",position_mine[0],position_mine[1]);
			}

//            position_mine[0] = (TIME_STEP * velocity_a[0] + sum_neigh[0]) / (1 + neigh_valid_count) +
//                               TIME_STEP * p_prusecik_vysledny[0] / 2;
//            position_mine[1] = (TIME_STEP * velocity_a[1] + sum_neigh[1]) / (1 + neigh_valid_count) +
//                               TIME_STEP * p_prusecik_vysledny[1] / 2;
//            my_validity_prus = 1;

//            printf("pos x %f, prus %f\n", position_mine[0], p_prusecik_vysledny[0]);

			sprintf(send_str, "-v:%d-px-%f,py-%f--", my_validity_prus * vision_data_validity, TIME_STEP * velocity_a[0],
			TIME_STEP * velocity_a[1]);
			if (simxSetStringSignal(clientID, send_name, (simxUChar *) send_str, strlen(send_str), simx_opmode_oneshot) != 0) {
				printf("simxSetStringSignal\n");
			}

			//nastaveni polohy koule
			if (position_mine[0] < 900 && position_mine[1] < 900) {
				errpom[0] = ERR_POS * real_rand();
				errpom[1] = ERR_POS * real_rand();
				position_mine[0] += errpom[0];
				position_mine[1] += errpom[1];
				err += sqrt(errpom[0] * errpom[0] + errpom[1] * errpom[1]);
				//                err = err/( position_mine[0]*position_mine[0] + position_mine[1]*position_mine[1] );
				if (simxSetObjectPosition(clientID, target_koule, target_koule, position_mine, simx_opmode_oneshot) != 0) {
					printf("simxSetObjectPosition\n");
				}
			}

			sum_neigh[0] = 0;
			sum_neigh[1] = 0;
			neigh_valid_count = 0;

			//printf("%d\n",simxGetLastCmdTime(clientID));
//            extApi_sleepMs(150);
			//simxSynchronousTrigger(clientID);

			//odeslani textu na konzoli
			/*------------------------------------------------------------------------------------------------------------------*/
			sprintf(text_pom, "validity : %6s Tx: %.3f  err:%.4f \n %17s Ty: %.3f \n", my_validity_prus * vision_data_validity > 0 ? "ANO" : "NE",
					target_pos[0], position_mine[0], vision_data_validity > 0 ? "TARGET" : "LOST", target_pos[1]);
			strcat(text, text_pom);
			err = 0;
			simxAuxiliaryConsolePrint(clientID, *console_handle, text, simx_opmode_oneshot_wait);
			sprintf(text, " ");
//            printf(".\n");

		}
		simxFinish(clientID);
	}

	//    free(p_prusecik1);
	//    free(p_prusecik2);
	//    free(p_prusecik_vysledny);
	//    free(p_pom_handl);
	//    free(p_neight_handles);
	//    free(p_velocity_neigh);
	//    for(int i = 0; i < 6; ++i){
	//        free(pp_auxVal[i]);
	//        free(pp_auxValc[i]);
	//    }
	//    free(pp_auxVal);
	//    free(pp_auxValc);

	return (0);
}

