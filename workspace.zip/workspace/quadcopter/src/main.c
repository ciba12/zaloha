// Copyright 2006-2015 Coppelia Robotics GmbH. All rights reserved.
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
//
// -------------------------------------------------------------------
// THIS FILE IS disTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
//
// You are free to use/modify/distribute this file for whatever purpose!
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.2 Rev1 on September 5th 2015

// Make sure to have the server side running in V-REP!
// Start the server from a child script with following command:
// simExtRemoteApiStart(portNumber) -- starts a remote API server service on the specified port

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
//
#define NON_MATLAB_PARSING
#define MAX_EXT_API_CONNECTIONS 255
//
#ifndef VREP
#define VREP

#include "v_repConst.h"
#include "extApiPlatform.h"
#endif

#include "extApi.h"
#include "extApi.c"
#include "extApiPlatform.c"
#include "pom_fce.h"

#define TIME_STEP 0.05 //[sec]
#define COV_MAT 1 // meni tvar krivky pro vypocet Mi, cim vetsi, tim rychlejsi zmeny, Mi=1-exp((x^2+y^2) * COVMAT)
#define TAU 3 //time interval for derivation, higher TAU, more robust
#define ALFA 0.036 //higher ALFA, higher sensitivity to target dynamic's variations
#define SWARM_QUANTITY 3  //velikost swarmu
#define NEIGH_DISTANCE 3 //range proximity senzoru
#define CIRCLE_DIST 1.8 //polomer kruhu ve kterzm se musi drzet
#define EPSILON 0.2


#define ERR_POS 0.0
#define ERR_VISION 0.0
#define ERR_DIST 0.0
#define real_rand() ((double)rand() / (RAND_MAX +1.0) -0.5)

#define CONSOLE_LINES 5

#define PI (3.141592653589793)


//funguje do 0.7, vic uz nejde protoze se kamery naklani
//#define KP 23
//#define KI 0.56
//#define KD 130
//#define GAIN 0.05

//funguje do 0.5 rychlosti
#define KP 20
#define KI 0.56
#define KD 0
#define GAIN 0.05


int main(int argc, char *argv[]) {
    int portNb = 0;
    int target_koule;
    int camera;
    int circle;
    int proximity[2];
    int ID;

    int truek = 1;

    float *p_prusecik1 = (float *) malloc(2 * sizeof(float));
    float *p_prusecik2 = (float *) malloc(2 * sizeof(float));
    float *p_prusecik_vysledny = (float *) malloc(2 * sizeof(float));
    float eps[2] = {0.0, 0.0};

    //prevzeti handlu pres argument
    if (argc >= 8) {
        portNb = atoi(argv[1]);
        target_koule = atoi(argv[2]);
        camera = atoi(argv[3]);
        circle = atoi(argv[4]);
        proximity[0] = atoi(argv[5]);
        proximity[1] = atoi(argv[6]);
        ID = atoi(argv[7]);
    }
    else {
        return 0;
    }

    simxUChar image[100 * 100];
    for (int k = 0; k < 100 * 100; k++) {
        image[k] = 0;
    }

    //inicializace
    float position_mine[3] = {0.0f, 0.0f, 0.0f};
    float position_neigh[3] = {0.0f, 0.0f, 0.0f}; // pozice souseda
    float velocity_a[3] = {0.0f, 0.0f, 0.0f}; //alfa velocity from target
    float sum_neigh[2] = {0.0f, 0.0f};

    float euler_angles[3] = {0.0f, 0.0f, 0.0f};
    int clientID = simxStart((simxChar *) "127.0.0.1", portNb, truek, truek, 2000, 5);
    //    simxSynchronous(clientID,true);

    //inicializace konzole
    char title[20];
    sprintf(title, "ID: %d", ID);
    int *console_handle = (int *) malloc(sizeof(int));
    int size[2] = {400, 2};
    int position_console[2] = {250, 1000 - 100 * ID};
    simxAuxiliaryConsoleOpen(clientID, title, CONSOLE_LINES, 1, position_console, size, NULL, NULL, console_handle,
                             simx_opmode_oneshot_wait);
    char text[200]; // pripraveny pro zapis do konzole
    char text_pom[100];

    float target_pos[2];
    float target_pos_int[2] = {0.0, 0.0};
    float target_pos_der[2] = {0.0, 0.0};
    float target_pos_old[2] = {0.0, 0.0};

    simxUChar detekce;

    //init. sledovani targetu
    float Mi = 0;
    float Ax = 0, Ay = 0, dAx = 0, dAy = 0;
    float Ax_array[TAU];
    float Ay_array[TAU];


    for (int i = 0; i < TAU; i++) {
        Ax_array[i] = 0;
        Ay_array[i] = 0;
    }

    simxFloat **pp_auxVal = (simxFloat **) malloc(sizeof(simxFloat *) * 6);
    for (int i = 0; i < 6; ++i)
        pp_auxVal[i] = (simxFloat *) malloc(sizeof(simxFloat) * 15);

    simxInt **pp_auxValc = (simxInt **) malloc(sizeof(simxInt *) * 6);
    for (int i = 0; i < 6; ++i)
        pp_auxValc[i] = (simxInt *) malloc(sizeof(simxInt) * 15);

    int neigh_valid_count = 0;
    int my_validity_prus = 0;
    int my_validity_vision = 0;

    char **receive_names = (char **) malloc(sizeof(char *) * SWARM_QUANTITY);
    for (int i = 0; i < SWARM_QUANTITY; i++) {
        receive_names[i] = (char *) malloc(sizeof(char) * 10);
        sprintf(receive_names[i], "%d", i + 1);
    }
    float koule_swarm[SWARM_QUANTITY][2];
    simxUChar **receive_str = (simxUChar **) malloc(sizeof(simxUChar *));
    receive_str[0] = (simxUChar *) malloc(sizeof(simxUChar) * 100);
    int *receive_lenght = (int *) malloc(sizeof(int));

    //beru handle odsud
    //simxGetObjectHandle(clientID, "Vision_sensor#0", &camera, simx_opmode_oneshot_wait);

    //pouze pozadavky na server aby zacal streamovat
    simxGetObjectPosition(clientID, target_koule, -1, position_mine, simx_opmode_streaming);
    simxReadVisionSensor(clientID, camera, &detekce, pp_auxVal, pp_auxValc, simx_opmode_streaming);
    simxGetObjectOrientation(clientID, camera, -1, euler_angles, simx_opmode_streaming);
    simxReadProximitySensor(clientID, proximity[0], NULL, position_neigh, NULL, NULL, simx_opmode_streaming);
    simxReadProximitySensor(clientID, proximity[1], NULL, position_neigh, NULL, NULL, simx_opmode_streaming);

    for (int i = 0; i < SWARM_QUANTITY; i++) {
        simxGetStringSignal(clientID, receive_names[i], receive_str, NULL, simx_opmode_streaming);
    }

    simxChar send_str[100];
    simxChar send_name[10];
    sprintf(send_name, "%d", ID);

    // uhel natoceni proxi senzoru
    float alf[2];
    switch (ID) {
        case 1:
            alf[0] = 60 * PI / 180;
            alf[1] = 0;
            break;
        case 2:
            alf[0] = -60 * PI / 180;
            alf[1] = -120 * PI / 180;
            break;
        case 3:
            alf[0] = 180 * PI / 180;
            alf[1] = 120 * PI / 180;
            break;
        default:
            break;
    }

    float PID_out[2];
    float distance;
    float rel_neigh_pos[2][2] = {{0.0, 0.0},
                                 {0.0, 0.0}};
    int prusecik_error = 1;

    float err = 0, errpom[2] = {0.0, 0.0};
    float Sx[2] = {0.0, 0.0};
    float Sy[2] = {0.0, 0.0};
    float Sdist[2] = {0.0, 0.0};

    float delta;
    float alfax, alfay;


    int first_smooth = 1;

    if (clientID != -1) {
        while (simxGetConnectionId(clientID) != -1)// dokud jsem pripojen k serveru....
        {

            //detekce targetu + vypocteni thrustu
            /*------------------------------------------------------------------------------------------------------------------*/
//            trajectory_planning(clientID, camera, ID, velocity_a, position_mine);


            if(simxReadVisionSensor(clientID,camera,&detekce,pp_auxVal,pp_auxValc,simx_opmode_buffer) == 0){
                for(int i=0;i<2;i++){
                    target_pos[i] = pp_auxVal[0][i+1] - 0.5;
                    if( target_pos[i] < -0.494){
                        target_pos[i]=0;
                        my_validity_vision = 0;
                    }else
                        my_validity_vision = 1;

                    errpom[0] = ERR_VISION*real_rand();
                    if(ID == 1 && i==0){

                        simxWriteStringStream(clientID,"VISION_X_CLEAN",(simxUChar *)target_pos,sizeof(distance),simx_opmode_oneshot);
                    }
                    if(ID == 1 && i==1){
                        simxWriteStringStream(clientID,"VISION_Y_CLEAN",(char *)(target_pos+1),sizeof(distance),simx_opmode_oneshot);
                    }

                    target_pos[i] +=  errpom[0];
                    err +=  sqrt(errpom[0]*errpom[0])*0.017;

                    if(ID == 1 && i==0){
                        simxWriteStringStream(clientID,"VISION_X_NOISE",(char *)target_pos,sizeof(distance),simx_opmode_oneshot);
                    }
                    if(ID == 1 && i==1){
                        simxWriteStringStream(clientID,"VISION_Y_NOISE",(char *)(target_pos+1),sizeof(distance),simx_opmode_oneshot);
                    }

                }

                if(first_smooth){
                    Sx[1] = target_pos[0];
                    Sy[1] =  target_pos[1];
                }
                delta = target_pos[0] - Sx[1];
                alfax = alfa_smooth(delta);
                Sx[0] = alfax*delta + Sx[1];

                delta = target_pos[1] - Sy[1];
                alfay = alfa_smooth(delta);
                Sy[0] = alfay*delta + Sy[1];

//                target_pos[0] = Sx[0];
//                target_pos[1] = Sy[0];

                Sx[1] = Sx[0];
                Sy[1] = Sy[0];
                if(ID == 1){
                    simxWriteStringStream(clientID,"VISION_X_SMOOTH",(char *)(target_pos),sizeof(distance),simx_opmode_oneshot);
                    simxWriteStringStream(clientID,"VISION_Y_SMOOTH",(char *)(target_pos+1),sizeof(distance),simx_opmode_oneshot);
                }


                for(int i=0;i<2;i++){
                    target_pos_int[i] += target_pos[i];
                    target_pos_der[i] = target_pos[i]-target_pos_old[i];
                    target_pos_old[i] = target_pos[i];

                    PID_out[i] = KP*target_pos[i] + KI*target_pos_int[i] + KD*target_pos_der[i];
                    velocity_a[i] = GAIN*PID_out[i];
                    sprintf(text_pom,"%s: %f ,det: %d\n",i==0?"x":"y",target_pos[i],detekce);
                    strcat(text,text_pom);
                }
                sprintf(text_pom,"x: Kp:%f  Ki:%f  Kd:%f \n",KP*target_pos[0],KI*target_pos_int[0],KD*target_pos_der[0]);
                strcat(text,text_pom);
            }



            //detekce polohy sousedu
            /*------------------------------------------------------------------------------------------------------------------*/
            for (int i = 0; i < 2; i++) {
                if (simxReadProximitySensor(clientID, proximity[i], NULL, position_neigh, NULL, NULL,
                                            simx_opmode_buffer) == 0) {
                    float z = position_neigh[2];
                    float y = position_neigh[1];
                    errpom[0] = real_rand() * ERR_DIST;
                    distance = sqrt(z * z + y * y);
                    if (ID == 1) {
                        simxWriteStringStream(clientID, "DIST_CLEAN", (char *) &distance, sizeof(distance),
                                              simx_opmode_oneshot);
                    }
                    distance += errpom[0];
                    if (ID == 1) {
                        simxWriteStringStream(clientID, "DIST_NOISE", (char *) &distance, sizeof(distance),
                                              simx_opmode_oneshot);
                    }
                    err += sqrt(errpom[0] * errpom[0]);

                    if (first_smooth)
                        Sdist[1] = distance;

                    delta = distance - Sdist[1];
                    alfax = alfa_smooth(delta);
                    Sdist[0] = alfax * delta + Sdist[1];
                    Sdist[1] = Sdist[0];

                    first_smooth = 0;

                    if (ID == 1) {
                        simxWriteStringStream(clientID, "DIST_SMOOTH", (char *) Sdist, sizeof(distance),
                                              simx_opmode_oneshot);
                    }
                    distance = Sdist[1];

                    rel_neigh_pos[i][0] = distance * cos(alf[i] + atan2(y, z));
                    rel_neigh_pos[i][1] = distance * sin(alf[i] + atan2(y, z));

                    //                    sprintf(text_pom,"%d:: %f*cos( %f + %f) cov:%f \n",i,distance,alf[i]*180/PI,atan2(y,z)*180/PI,COV_MAT);
                    //                    strcat(text,text_pom);

                    //eps pro intersection rule
                    eps[i] = distance - CIRCLE_DIST;
                    if (eps[i] < 0)
                        eps[i] = -eps[i];
                    //                    sprintf(text_pom,"eps %d: %f, EPS: %f\n",i,eps[i],EPSILON);
                    //                    strcat(text,text_pom);



                } else {
                    printf("simxReadProximitySensor\n");
                }
            }

            //            printf("neigh:1: %f %f   2:%f %f",);
            //prijem rychlosti sousedu
            /*------------------------------------------------------------------------------------------------------------------*/
            for (int i = 0; i < SWARM_QUANTITY; i++) {
                if (i + 1 != ID) {
                    if (simxGetStringSignal(clientID, receive_names[i], receive_str, receive_lenght,
                                            simx_opmode_buffer) != 0) {
                        printf("simxGetStringSignal\n");
                    }
                    receive_str[0][32] = '\0';
                    int val;

                    sscanf(*((char **) receive_str), "-v:%d-px-%f,py-%f-- ", &val, koule_swarm[i], koule_swarm[i] + 1);
                    if (val == 1) {
                        sum_neigh[0] += koule_swarm[i][0];
                        sum_neigh[1] += koule_swarm[i][1];
                        neigh_valid_count++;

                    } else {
                        sum_neigh[0] += 0;
                        sum_neigh[1] += 0;
                    }


                }
            }
            switch (ID) {
                case '1' :
                    rel_neigh_pos[0][0] += koule_swarm[2 - 1][0];
                    rel_neigh_pos[0][1] += koule_swarm[2 - 1][1];

                    rel_neigh_pos[1][0] += koule_swarm[3 - 1][0];
                    rel_neigh_pos[1][1] += koule_swarm[3 - 1][1];
                    break;
                case '2' :
                    rel_neigh_pos[0][0] += koule_swarm[3 - 1][0];
                    rel_neigh_pos[0][1] += koule_swarm[3 - 1][1];

                    rel_neigh_pos[1][0] += koule_swarm[1 - 1][0];
                    rel_neigh_pos[1][1] += koule_swarm[1 - 1][1];
                    break;
                case '3' :
                    rel_neigh_pos[0][0] += koule_swarm[1 - 1][0];
                    rel_neigh_pos[0][1] += koule_swarm[1 - 1][1];

                    rel_neigh_pos[1][0] += koule_swarm[2 - 1][0];
                    rel_neigh_pos[1][1] += koule_swarm[2 - 1][1];
                    break;
            }


            //            printf("sum: %f,%f\n",sum_neigh[0],sum_neigh[1]);

            //pocitani pruseciku
            /*------------------------------------------------------------------------------------------------------------------*/
            if (prusecik(rel_neigh_pos[0], rel_neigh_pos[1], CIRCLE_DIST, p_prusecik1, p_prusecik2) != 0) {
                printf("prusecik\n");
                prusecik_error = 1;
            } else {
                prusecik_error = 0;
            }

            if (sqrt(pow(p_prusecik1[0], 2) + pow(p_prusecik1[1], 2)) >
                sqrt(pow(p_prusecik2[0], 2) + pow(p_prusecik2[1], 2))) {
                p_prusecik_vysledny = p_prusecik2;
            } else {
                p_prusecik_vysledny = p_prusecik1;
            }


            //update polohy koule
            /*------------------------------------------------------------------------------------------------------------------*/
            //odeslu svou vypocitanou rychlost ostatnim


            if (eps[0] > EPSILON || eps[1] > EPSILON || prusecik_error) {
                //zprumeruju s ostatnima
                position_mine[0] = TIME_STEP * p_prusecik_vysledny[0] / 3;
                position_mine[1] = TIME_STEP * p_prusecik_vysledny[1] / 3;
                my_validity_prus = 0;
                //                                printf("prumer s ostatnima : %f,,,%f\n",position_mine[0],position_mine[1]);
            } else {
                //jdu do pruseciku
                position_mine[0] = (TIME_STEP * velocity_a[0] + sum_neigh[0]) / (1 + neigh_valid_count);
                position_mine[1] = (TIME_STEP * velocity_a[1] + sum_neigh[1]) / (1 + neigh_valid_count);
                my_validity_prus = 1;
                //                                printf("prusecik vysledny: %f,,,%f\n",position_mine[0],position_mine[1]);
            }

//            position_mine[0] = (TIME_STEP * velocity_a[0] + sum_neigh[0]) / (1 + neigh_valid_count) +
//                               TIME_STEP * p_prusecik_vysledny[0] / 2;
//            position_mine[1] = (TIME_STEP * velocity_a[1] + sum_neigh[1]) / (1 + neigh_valid_count) +
//                               TIME_STEP * p_prusecik_vysledny[1] / 2;
//            my_validity_prus = 1;


            printf("pos x %f, prus %f\n", position_mine[0], p_prusecik_vysledny[0]);


            sprintf(send_str, "-v:%d-px-%f,py-%f--", my_validity_prus * my_validity_vision, TIME_STEP * velocity_a[0],
                    TIME_STEP * velocity_a[1]);
            if (simxSetStringSignal(clientID, send_name, (simxUChar *) send_str, strlen(send_str),
                                    simx_opmode_oneshot) != 0) {
                printf("simxSetStringSignal\n");
            }




            //nastaveni polohy koule
            if (position_mine[0] < 900 && position_mine[1] < 900) {
                errpom[0] = ERR_POS * real_rand();
                errpom[1] = ERR_POS * real_rand();
                position_mine[0] += errpom[0];
                position_mine[1] += errpom[1];
                err += sqrt(errpom[0] * errpom[0] + errpom[1] * errpom[1]);
                //                err = err/( position_mine[0]*position_mine[0] + position_mine[1]*position_mine[1] );
                if (simxSetObjectPosition(clientID, target_koule, target_koule, position_mine, simx_opmode_oneshot) !=
                    0) {
                    printf("simxSetObjectPosition\n");
                }
            }

            sum_neigh[0] = 0;
            sum_neigh[1] = 0;
            neigh_valid_count = 0;

            //printf("%d\n",simxGetLastCmdTime(clientID));
//            extApi_sleepMs(150);
            //simxSynchronousTrigger(clientID);

            //odeslani textu na konzoli
            /*------------------------------------------------------------------------------------------------------------------*/
            sprintf(text_pom, "validity : %6s Tx: %.3f  err:%.4f \n %17s Ty: %.3f \n",
                    my_validity_prus * my_validity_vision > 0 ? "ANO" : "NE", target_pos[0], position_mine[0],
                    my_validity_vision > 0 ? "TARGET" : "LOST", target_pos[1]);
            strcat(text, text_pom);
            err = 0;
            simxAuxiliaryConsolePrint(clientID, *console_handle, text, simx_opmode_oneshot_wait);
            sprintf(text, " ");
            printf(".\n");

        }
        simxFinish(clientID);
    }

    //    free(p_prusecik1);
    //    free(p_prusecik2);
    //    free(p_prusecik_vysledny);
    //    free(p_pom_handl);
    //    free(p_neight_handles);
    //    free(p_velocity_neigh);
    //    for(int i = 0; i < 6; ++i){
    //        free(pp_auxVal[i]);
    //        free(pp_auxValc[i]);
    //    }
    //    free(pp_auxVal);
    //    free(pp_auxValc);

    return (0);
}

