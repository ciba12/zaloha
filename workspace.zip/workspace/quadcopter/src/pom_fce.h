//
// Created by ciba on 14.1.2016.
//

#ifndef QUAD_POM_FCE_H
#define QUAD_POM_FCE_H

int prusecik(float A[2],float B[2], float dist, float *prus1,float *prus2 );
float fce1(float x,float y);
float fce2(float x,float y,float dx,float dy);
float alfa_smooth(float delta);
int min_smooth(float a,float b,float c);
int vision(int clientID, int camera, int ID, float velocity_a[2] );
int trajectory_planning(int clientID, int camera, int ID, float *velocity_a, float *position_mine);

#endif