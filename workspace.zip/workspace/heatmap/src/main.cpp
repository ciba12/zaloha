// Copyright 2006-2015 Coppelia Robotics GmbH. All rights reserved.
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
//
// -------------------------------------------------------------------
// THIS FILE IS disTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
//
// You are free to use/modify/distribute this file for whatever purpose!
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.2 Rev1 on September 5th 2015

// Make sure to have the server side running in V-REP!
// Start the server from a child script with following command:
// simExtRemoteApiStart(portNumber) -- starts a remote API server service on the specified port

#include <stdio.h>
#include <stdlib.h>
#include <cmath>
#include <cstring>
#include <time.h>

#define NON_MATLAB_PARSING
#define MAX_EXT_API_CONNECTIONS 255

// error pro pozici a kameru, 1 = 100%
#define ERR_POS 0.4 //error z maxima
#define ERR_VISION 0.1 //error ze soucasne polohy

#define BIG 6
#define SMALL 3


#include "extApi.h"
#include "extApi.c"
#include "extApiPlatform.h"
#include "extApiPlatform.c"


#define real_rand() ((double)rand() / (RAND_MAX +1.0))

//extern "C" {
//#include "extApi.h"
//#include "extApiPlatform.h"
//}
/*	#include "extApiCustom.h" if you wanna use custom remote API functions! */

int max(int a,int b){
    return a>b?a:b;
}
int min(int a,int b){
    return a<b?a:b;
}

int main(int argc,char* argv[])
{
    int portNb=0;
    int heat_vision;
    int camera;



    //prevzeti handlu pres argument
    if (argc>=3)
    {
        portNb=atoi(argv[1]);
        heat_vision=atoi(argv[2]);
        camera=atoi(argv[3]);

    }
    else
    {
        return 0;
    }

    int clientID=simxStart((simxChar*)"127.0.0.1",portNb,1,1,2000,5);

    simxFloat** pp_auxVal = (simxFloat **) malloc(sizeof(simxFloat *) * 6);
    for(int i = 0; i < 6; ++i)
        pp_auxVal[i] = (simxFloat *) malloc(sizeof(simxFloat) * 15);

    simxInt** pp_auxValc = (simxInt **) malloc(sizeof(simxInt *) * 6);
    for(int i = 0; i < 6; ++i)
        pp_auxValc[i] = (simxInt *) malloc(sizeof(simxInt) * 15);

    simxUChar image[100*100*3];
    for(int y=0;y<100;y++){
        for(int x=0;x<100;x++){
            image[(y*3*100+3*x)] = 0;   // R
            image[(y*3*100+3*x)+1] = 0; // G
            image[(y*3*100+3*x)+2] = 0;  // B
        }
    }

    int image2[100*100];
    for(int y=0;y<100;y++){
        for(int x=0;x<100;x++){
            image2[(y*100+x)] = 0.0;
        }
    }
    int pom;

    float target_pos[2];
    simxUChar detekce;
    int draw = 0;
    time_t cas1,cas2;
    time(&cas1);
    simxReadVisionSensor(clientID,camera,&detekce,pp_auxVal,pp_auxValc,simx_opmode_streaming);

    if (clientID!=-1)
    {
        while (simxGetConnectionId(clientID)!=-1)// dokud jsem pripojen k serveru....
        {
            if(simxReadVisionSensor(clientID,camera,&detekce,pp_auxVal,pp_auxValc,simx_opmode_buffer) == 0) {
                for (int i = 0; i < 2; i++) {
                    target_pos[i] = pp_auxVal[0][i + 1] * 100;
                    if (target_pos[i] < -49.4) {
                        draw = 0;
                    } else
                        draw = 1;
                }

                int x = target_pos[0];
                int y = target_pos[1];


                if (draw == 1){
                    for (int i = max(y - BIG, 0); i <= min(BIG + y, 100); i++) {
                        for (int k = max(-BIG + x, 0); k <= min(BIG + x, 100); k++) {
                            if (image2[(i * 100 + k)] < 3 * 255) {
                                image2[(i * 100 + k)] += 1;
                                if (i > y - SMALL && i < y + SMALL && k > x - SMALL && k < x + SMALL)
                                    image2[(i * 100 + k)] += 1;
                                if (i == y && k == x)
                                    image2[(i * 100 + k)] += 1;
                            }

                        }
                    }
                }
            }




            time(&cas2);
            //            if(difftime(cas2,cas1) > 0){

            for(int y=0;y<100;y++){
                for(int x=0;x<100;x++){
                    pom = 255 - abs(image2[(y*100+x)] - 255); //G
                    pom = pom<0? pom = 0 : pom;
                    image[(y*3*100+3*x)+1] = pom;

                    pom = 255 - abs(image2[(y*100+x)] - 2*255); //B
                    pom = pom<0? pom = 0 : pom;
                    image[(y*3*100+3*x)+2] = pom;

                    pom = 255 - abs(image2[(y*100+x)] - 3*255); //R
                    pom = pom<0? pom = 0 : pom;
                    image[(y*3*100+3*x)] = pom;
                }
            }




            simxSetVisionSensorImage(clientID,heat_vision,image,100*100*3,0,simx_opmode_oneshot);
            time(&cas1);
            //            }
            extApi_sleepMs(20);
        }
    }

    simxFinish(clientID);

    return(0);
}


